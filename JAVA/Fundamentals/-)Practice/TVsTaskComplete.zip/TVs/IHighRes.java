public interface IHighRes {
    void improveQuality();
}