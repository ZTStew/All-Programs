public class ExceptionsTest {                                                   // creates a class named, 'ExceptionsTest'
    public static void main(String[] args){                                     // creates an entry point method that expects no returns
        ExceptionsDemo list = new ExceptionsDemo();                             // creates an object named, 'list', an instance of ExceptionsDemo
        list.exList();                                                          // runs the 'exList' method belonging to 'list'
    }
}
