import java.util.HashMap;                                                       // allows file to use HashMaps
public class MapsDemo {                                                         // creates a class named, 'MapsDemo'

}
