
public class ObjectMasterWizard {

}
