
public class ObjectMasterSamurai {

}
