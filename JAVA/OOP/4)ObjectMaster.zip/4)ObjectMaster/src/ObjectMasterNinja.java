
public class ObjectMasterNinja {

}
